# Week 1 Frontend Fundamentals – Assignments & Mini Project

## Included
1. Personal Portfolio Website – HTML5 + CSS3 responsive design
2. React Components Practice – Header, Footer, Card, Button, Form using props/state
3. React Blog UI – JSON data, search and filter functionality

## How to run the React project
1. Install Node.js.
2. Open the `react-blog-ui` folder in a terminal.
3. Run `npm install`
4. Run `npm run dev`
