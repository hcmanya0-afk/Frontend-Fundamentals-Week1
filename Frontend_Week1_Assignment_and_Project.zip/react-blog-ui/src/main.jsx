import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import './style.css';

const posts=[
 {id:1,title:'Learning HTML5',category:'HTML',text:'Semantic HTML creates meaningful and accessible page structure.'},
 {id:2,title:'CSS Flexbox Basics',category:'CSS',text:'Flexbox helps create flexible one-dimensional layouts.'},
 {id:3,title:'JavaScript ES6+',category:'JavaScript',text:'Modern JavaScript includes let, const, arrow functions and more.'},
 {id:4,title:'Getting Started with React',category:'React',text:'React uses reusable components, props, state and events.'},
 {id:5,title:'Responsive Web Design',category:'CSS',text:'Responsive design makes websites work well on different screen sizes.'}
];

function Header(){return <header><h1>My React Blog</h1><p>Frontend Fundamentals</p></header>}
function Footer(){return <footer>© 2026 My React Blog</footer>}
function Card({post}){return <article className="card"><span>{post.category}</span><h2>{post.title}</h2><p>{post.text}</p></article>}
function Button({children,onClick}){return <button onClick={onClick}>{children}</button>}
function Form({onAdd}){const [title,setTitle]=useState(''); return <form onSubmit={e=>{e.preventDefault();if(title.trim()){onAdd(title);setTitle('')}}}><input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Add a post title"/><Button>Add</Button></form>}

function App(){
 const [query,setQuery]=useState('');
 const [category,setCategory]=useState('All');
 const [items,setItems]=useState(posts);
 const cats=['All',...new Set(posts.map(p=>p.category))];
 const filtered=items.filter(p=>(category==='All'||p.category===category)&&
 (p.title.toLowerCase().includes(query.toLowerCase())||p.text.toLowerCase().includes(query.toLowerCase())));
 const addPost=title=>setItems([...items,{id:Date.now(),title,category:'New',text:'This is a new blog post.'}]);
 return <><Header/><main><Form onAdd={addPost}/><div className="controls"><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search posts..."/><select value={category} onChange={e=>setCategory(e.target.value)}>{cats.map(c=><option key={c}>{c}</option>)}</select></div><section className="grid">{filtered.map(p=><Card key={p.id} post={p}/>)}</section>{filtered.length===0&&<p className="empty">No posts found.</p>}</main><Footer/></>
}
createRoot(document.getElementById('root')).render(<App/>);
