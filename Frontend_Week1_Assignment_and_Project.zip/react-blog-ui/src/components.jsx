// Reusable React Components Practice
import React,{useState} from 'react';

export function Header(){return <header><h1>My Website</h1></header>}
export function Footer(){return <footer>© 2026 My Website</footer>}
export function Card({title,description}){return <div><h2>{title}</h2><p>{description}</p></div>}
export function Button({children,onClick}){return <button onClick={onClick}>{children}</button>}
export function Form(){const [name,setName]=useState('');return <form onSubmit={e=>{e.preventDefault();alert(`Hello ${name}`)}}><input value={name} onChange={e=>setName(e.target.value)} placeholder="Enter name"/><Button>Submit</Button></form>}
