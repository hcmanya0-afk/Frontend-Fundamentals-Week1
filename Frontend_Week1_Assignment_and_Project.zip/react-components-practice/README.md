# React Components Practice

The `src/components` folder contains five reusable components:
- Header
- Footer
- Card
- Button
- Form

Props are used for dynamic content. State is used in the form and button interactions.
