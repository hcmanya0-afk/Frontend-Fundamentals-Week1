import React, {useState} from "react";
import {createRoot} from "react-dom/client";
import "./style.css";

function Header(){return <header><h1>React Components Practice</h1><p>Reusable components using props and state</p></header>}
function Card({title, text}){return <article className="card"><h3>{title}</h3><p>{text}</p></article>}
function Button({children, onClick}){return <button onClick={onClick}>{children}</button>}
function Form({onSubmit}){const [value,setValue]=useState("");return <form onSubmit={e=>{e.preventDefault();onSubmit(value);setValue("")}}><input value={value} onChange={e=>setValue(e.target.value)} placeholder="Enter your name" required/><Button>Submit</Button></form>}
function Footer(){return <footer>© 2026 React Practice</footer>}

function App(){
  const [count,setCount]=useState(0);
  const [message,setMessage]=useState("No name submitted yet.");
  return <div className="app">
    <Header/>
    <main>
      <section className="cards">
        <Card title="Header" text="Reusable page header component."/>
        <Card title="Footer" text="Reusable footer component."/>
        <Card title="Card" text="Reusable content card using props."/>
        <Card title="Button" text="Reusable button component."/>
        <Card title="Form" text="Form component using state."/>
      </section>
      <section className="demo">
        <h2>State Example</h2>
        <p>Button clicked: <strong>{count}</strong> times</p>
        <Button onClick={()=>setCount(count+1)}>Click Me</Button>
        <h2>Props + Form Example</h2>
        <Form onSubmit={name=>setMessage(`Hello, ${name}!`)}/>
        <p>{message}</p>
      </section>
    </main>
    <Footer/>
  </div>
}
createRoot(document.getElementById("root")).render(<App/>);