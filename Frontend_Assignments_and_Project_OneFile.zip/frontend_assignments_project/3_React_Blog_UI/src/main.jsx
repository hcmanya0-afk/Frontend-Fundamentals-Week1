import React,{useState} from "react";
import {createRoot} from "react-dom/client";
import posts from "./posts.json";
import "./style.css";

function PostCard({post}){return <article className="post"><span>{post.category}</span><h2>{post.title}</h2><p>{post.excerpt}</p><button>Read More</button></article>}

function App(){
  const [search,setSearch]=useState("");
  const [category,setCategory]=useState("All");
  const categories=["All",...new Set(posts.map(p=>p.category))];
  const filtered=posts.filter(p=>(category==="All"||p.category===category)&&
    (p.title.toLowerCase().includes(search.toLowerCase())||p.excerpt.toLowerCase().includes(search.toLowerCase())));
  return <div>
    <header><h1>My React Blog</h1><p>Frontend learning and development</p></header>
    <main>
      <div className="controls">
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search posts..."/>
        <select value={category} onChange={e=>setCategory(e.target.value)}>
          {categories.map(c=><option key={c}>{c}</option>)}
        </select>
      </div>
      <p className="count">{filtered.length} post(s) found</p>
      <section className="posts">
        {filtered.length ? filtered.map(post=><PostCard key={post.id} post={post}/>) :
          <p>No posts found. Try another search.</p>}
      </section>
    </main>
    <footer>© 2026 My React Blog</footer>
  </div>
}
createRoot(document.getElementById("root")).render(<App/>);