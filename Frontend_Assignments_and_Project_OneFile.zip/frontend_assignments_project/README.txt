WEEK 1 FRONTEND FUNDAMENTALS
Assignments + Mini Project

1) 1_Personal_Portfolio
   - Responsive HTML/CSS portfolio
   - Sections: About, Education, Projects, Contact
   - Contact form interaction with JavaScript

2) 2_React_Components_Practice
   - Header, Footer, Card, Button, Form components
   - Props and state examples

3) 3_React_Blog_UI
   - React blog post cards loaded from posts.json
   - Search and category filter

HOW TO RUN THE PORTFOLIO:
Open 1_Personal_Portfolio/index.html in a browser.

HOW TO RUN EACH REACT PROJECT:
1. Install Node.js.
2. Open the project folder in VS Code terminal.
3. Run: npm install
4. Run: npm run dev
5. Open the local address shown by Vite.

You can replace the sample portfolio details with your own details before submitting.
